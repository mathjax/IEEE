window.MathJax = {
  loader: {
    load: [
      '[tex]/ieeemacros',
      '[tex]/ieeelegacy',
      '[tex]/ieeestix',
      '[tex]/eulerieee',
      '[tex]/bbm',
      '[tex]/bboldx',
      '[tex]/boldsymbol',
      '[tex]/dsfont',
      '[tex]/upgreek',
      '[tex]/textmacros',
      '[tex]/textcomp',
      '[tex]/colortbl',
      'ui/lazy',
    ],
    versionWarnings: false
  },
  tex: {
    inlineMath: [
      ['$','$'],      
      ['\\(','\\)']
    ],
    packages: {'[+]': [
      'ieeemacros',
      'ieeelegacy',
      'ieeestix',
      'eulerieee',
      'bbm',
      'bboldx',
      'boldsymbol',
      'dsfont',
      'upgreek',
      'textmacros',
      'textcomp',
      'colortbl'
    ]}
  },
  options: {
    a11y: {
      subtitles: true
    }
  },
  output: {
    font: 'mathjax-stix2',
  }
};
